# N-Perform Engineering Pack V1.0

本包把《数据库详细设计与 API 契约 V1.0》转成首批可供工程评审的文件骨架：
- `db/migrations/001_core_schema.sql`：PostgreSQL 核心 schema 基线
- `api/openapi.yaml`：OpenAPI 3.1 API 契约骨架
- `events/contribution-claim-submitted.schema.json`：领域事件 JSON Schema 示例
- `docs/erd.mmd`：Mermaid ERD
- `docs/state-machines.mmd`：核心状态机图
- `docs/adr/`：关键架构决策模板
- `tests/invariants.md`：必须自动化验证的业务不变量

## 重要说明
这是 **V1.0 工程起始包**，不是已经在生产环境验证的完整系统，也不是全量数据库实现。
上线前必须完成真实订单样本映射、财务规则确认、权限矩阵评审、迁移脚本 CI 验证与安全审查。
SQL 中包含首版核心表和约束；仍需按团队最终 ADR 补齐连接器、索引、策略、RLS 覆盖和生产运维设置。

## 推荐执行顺序
1. 使用 PostgreSQL 15+ 在临时数据库运行迁移。
2. 为所有租户业务表补齐/验证 RLS 策略；应用连接角色不得拥有绕过 RLS 的权限。
3. 根据真实订单 fixtures 验证工作包、证据、贡献认定闭环。
4. 对 OpenAPI 运行 lint 与生成客户端，确保服务实现与契约一致。
5. 对事件 schema 运行 schema validation；为消费者添加 Inbox 去重与重放测试。
6. 先进行影子周期；对账一致后再允许正式锁账。

## 约定
- 时间使用 `timestamptz`，应用统一传 UTC。
- 金额使用 `numeric`，API 金额字符串化。
- 锁定账本不允许更新或删除；纠错通过追加 adjustment/reversal。
- AI 输出只进入草稿/建议对象，不直接写正式评价或金额。
