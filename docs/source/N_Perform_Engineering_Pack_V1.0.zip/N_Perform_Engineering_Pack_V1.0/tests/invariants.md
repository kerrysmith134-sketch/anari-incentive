# Required Invariant Tests

1. Cross-tenant object references are rejected by DB constraints and service authorization.
2. Duplicate source events and duplicate webhook messages do not create duplicate incentive effects.
3. Any BLOCKING data-quality issue prevents formal calculation unless an explicit, audited override policy is used.
4. AI drafts/suggestions cannot directly create formal EvaluationDecision or AmountLedger rows.
5. Only an approved and effective policy version can be used in a formal calculation.
6. The same input snapshot + policy version + engine version produces the same result hash.
7. Main calculation and independent reference calculation mismatch blocks approval/lock.
8. Locked ledger rows cannot be updated/deleted by application roles; corrections append new entries.
9. Approval payload hash changes invalidate prior approval.
10. Same idempotency key and same payload is replay-safe; same key with different payload returns conflict.
11. Appeals preserve the original decision and ledger history.
12. Agent tools cannot bypass tenant/object/action permissions, state machine, data-quality gates, or approval requirements.
13. Worker crash and duplicate event replay do not cause duplicate ledger posting.
14. LLM/model provider outage does not prevent manual review and deterministic calculation.
15. Every high-impact action can be traced to actor, timestamp, correlation ID, input/output hashes, and approval record.
