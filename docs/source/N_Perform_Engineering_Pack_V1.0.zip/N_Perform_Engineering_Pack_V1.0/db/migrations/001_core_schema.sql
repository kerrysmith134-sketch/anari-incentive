-- N-Perform V1.0 core schema baseline
-- PostgreSQL 15+. Review with DBA before production use.
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TYPE tenant_status AS ENUM ('ACTIVE','SUSPENDED','CLOSED');
CREATE TYPE membership_status AS ENUM ('INVITED','ACTIVE','SUSPENDED','LEFT');
CREATE TYPE quality_status AS ENUM ('VALID','MISSING','STALE','CONFLICTED','UNVERIFIED','INVALID');
CREATE TYPE claim_status AS ENUM ('DRAFT','SUBMITTED','NEEDS_INFO','UNDER_REVIEW','ACCEPTED','PARTIALLY_ACCEPTED','REJECTED','WITHDRAWN');
CREATE TYPE cycle_status AS ENUM ('DRAFT','COLLECTING','DATA_REVIEW','EVALUATING','MANAGER_REVIEW','EMPLOYEE_REVIEW','APPEAL_REVIEW','READY_TO_SETTLE','SETTLING','CLOSED');
CREATE TYPE calculation_status AS ENUM ('CREATED','RUNNING','BLOCKED','FAILED','SUCCEEDED','PENDING_APPROVAL','APPROVED','LOCKED');
CREATE TYPE ledger_status AS ENUM ('PROVISIONAL','APPROVED','LOCKED','REVERSED');
CREATE TYPE settlement_status AS ENUM ('DRAFT','RECONCILED','PENDING_APPROVAL','APPROVED','SETTLED','FAILED','REVERSED');
CREATE TYPE agent_task_status AS ENUM ('QUEUED','RUNNING','WAITING_APPROVAL','RETRY_PENDING','BLOCKED','FAILED','ESCALATED','SUCCEEDED','CANCELLED');

CREATE TABLE tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  status tenant_status NOT NULL DEFAULT 'ACTIVE',
  default_timezone text NOT NULL DEFAULT 'UTC',
  default_currency char(3) NOT NULL DEFAULT 'USD',
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email citext,
  display_name text NOT NULL,
  auth_subject text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'ACTIVE',
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  user_id uuid NOT NULL REFERENCES users(id),
  status membership_status NOT NULL DEFAULT 'INVITED',
  role_codes text[] NOT NULL DEFAULT '{}',
  joined_at timestamptz,
  left_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id),
  UNIQUE (tenant_id, id)
);

CREATE TABLE people (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  user_id uuid REFERENCES users(id),
  employee_code text NOT NULL,
  display_name text NOT NULL,
  employment_status text NOT NULL DEFAULT 'ACTIVE',
  manager_person_id uuid,
  effective_from date NOT NULL DEFAULT CURRENT_DATE,
  effective_to date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, employee_code),
  UNIQUE (tenant_id, id),
  CHECK (effective_to IS NULL OR effective_to >= effective_from),
  FOREIGN KEY (tenant_id, manager_person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE org_nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  parent_id uuid,
  node_type text NOT NULL,
  name text NOT NULL,
  path text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, parent_id) REFERENCES org_nodes(tenant_id, id)
);

CREATE TABLE person_org_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  person_id uuid NOT NULL,
  org_node_id uuid NOT NULL,
  valid_from date NOT NULL,
  valid_to date,
  allocation numeric(8,5),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (valid_to IS NULL OR valid_to >= valid_from),
  CHECK (allocation IS NULL OR (allocation >= 0 AND allocation <= 1)),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, org_node_id) REFERENCES org_nodes(tenant_id, id)
);

CREATE TABLE raw_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  source_system text NOT NULL,
  source_record_id text NOT NULL,
  source_event_version text NOT NULL DEFAULT '1',
  event_type text NOT NULL,
  occurred_at timestamptz,
  ingested_at timestamptz NOT NULL DEFAULT now(),
  payload jsonb NOT NULL,
  payload_hash text NOT NULL,
  idempotency_fingerprint text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, source_system, source_record_id, source_event_version),
  UNIQUE (tenant_id, id)
);

CREATE TABLE evidence_nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  raw_event_id uuid,
  evidence_type text NOT NULL,
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  source_system text NOT NULL,
  source_uri text,
  observed_at timestamptz NOT NULL,
  valid_from timestamptz,
  valid_to timestamptz,
  quality_status quality_status NOT NULL DEFAULT 'UNVERIFIED',
  confidence numeric(5,4),
  normalized_payload jsonb NOT NULL,
  payload_hash text NOT NULL,
  supersedes_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (confidence IS NULL OR (confidence >= 0 AND confidence <= 1)),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, raw_event_id) REFERENCES raw_events(tenant_id, id),
  FOREIGN KEY (tenant_id, supersedes_id) REFERENCES evidence_nodes(tenant_id, id)
);

CREATE TABLE evidence_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  from_evidence_id uuid NOT NULL,
  to_evidence_id uuid NOT NULL,
  relation_type text NOT NULL CHECK (relation_type IN ('DEPENDENCY','CORRECTION','SUPPORTS','CONTRADICTS','CONTEXT')),
  rationale text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, from_evidence_id, to_evidence_id, relation_type),
  FOREIGN KEY (tenant_id, from_evidence_id) REFERENCES evidence_nodes(tenant_id, id),
  FOREIGN KEY (tenant_id, to_evidence_id) REFERENCES evidence_nodes(tenant_id, id),
  CHECK (from_evidence_id <> to_evidence_id)
);

CREATE TABLE data_quality_issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  evidence_id uuid,
  object_type text NOT NULL,
  object_id uuid NOT NULL,
  issue_code text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('INFO','WARNING','BLOCKING')),
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','IN_PROGRESS','RESOLVED','WAIVED')),
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  assigned_to uuid,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES evidence_nodes(tenant_id, id),
  FOREIGN KEY (tenant_id, assigned_to) REFERENCES people(tenant_id, id)
);

CREATE TABLE work_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  source_object_type text NOT NULL,
  source_object_id uuid NOT NULL,
  title text NOT NULL,
  objective text NOT NULL,
  package_type text NOT NULL,
  owner_person_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'DRAFT',
  priority text NOT NULL DEFAULT 'NORMAL',
  start_at timestamptz,
  due_at timestamptz,
  acceptance_criteria jsonb NOT NULL DEFAULT '[]'::jsonb,
  parent_work_package_id uuid,
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, owner_person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, parent_work_package_id) REFERENCES work_packages(tenant_id, id),
  CHECK (due_at IS NULL OR start_at IS NULL OR due_at >= start_at)
);

CREATE INDEX idx_work_packages_status_due ON work_packages(tenant_id, status, due_at);
CREATE INDEX idx_work_packages_source ON work_packages(tenant_id, source_object_type, source_object_id);

CREATE TABLE work_package_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  work_package_id uuid NOT NULL,
  person_id uuid NOT NULL,
  responsibility_code text NOT NULL,
  expected_output text NOT NULL,
  allocation_hint numeric(8,5),
  active_from timestamptz NOT NULL DEFAULT now(),
  active_to timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, work_package_id, person_id, responsibility_code, active_from),
  FOREIGN KEY (tenant_id, work_package_id) REFERENCES work_packages(tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id),
  CHECK (allocation_hint IS NULL OR (allocation_hint >= 0 AND allocation_hint <= 1)),
  CHECK (active_to IS NULL OR active_to >= active_from)
);

CREATE TABLE deliverables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  work_package_id uuid NOT NULL,
  title text NOT NULL,
  deliverable_type text NOT NULL,
  owner_person_id uuid NOT NULL,
  due_at timestamptz,
  status text NOT NULL DEFAULT 'DRAFT',
  artifact_ref text,
  content_hash text,
  submitted_at timestamptz,
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, work_package_id) REFERENCES work_packages(tenant_id, id),
  FOREIGN KEY (tenant_id, owner_person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE acceptances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  deliverable_id uuid NOT NULL,
  decision text NOT NULL CHECK (decision IN ('ACCEPT','REJECT','ACCEPT_WITH_ISSUES')),
  reviewer_person_id uuid NOT NULL,
  criteria_results jsonb NOT NULL DEFAULT '{}'::jsonb,
  comments text,
  decided_at timestamptz NOT NULL DEFAULT now(),
  supersedes_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, deliverable_id) REFERENCES deliverables(tenant_id, id),
  FOREIGN KEY (tenant_id, reviewer_person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, supersedes_id) REFERENCES acceptances(tenant_id, id)
);

CREATE TABLE evaluation_cycles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  name text NOT NULL,
  cycle_type text NOT NULL,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz NOT NULL,
  timezone text NOT NULL,
  status cycle_status NOT NULL DEFAULT 'DRAFT',
  policy_version_id uuid,
  rubric_version_id uuid,
  opened_at timestamptz,
  locked_at timestamptz,
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  CHECK (ends_at > starts_at)
);

CREATE TABLE contribution_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  cycle_id uuid,
  work_package_id uuid,
  claimant_person_id uuid NOT NULL,
  claim_type text NOT NULL,
  claimed_contribution jsonb NOT NULL,
  rationale text NOT NULL,
  status claim_status NOT NULL DEFAULT 'DRAFT',
  submitted_at timestamptz,
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, work_package_id) REFERENCES work_packages(tenant_id, id),
  FOREIGN KEY (tenant_id, claimant_person_id) REFERENCES people(tenant_id, id)
);
CREATE INDEX idx_claims_status_submitted ON contribution_claims(tenant_id, status, submitted_at DESC);

CREATE TABLE claim_evidence_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  claim_id uuid NOT NULL,
  evidence_id uuid NOT NULL,
  link_role text NOT NULL CHECK (link_role IN ('SUPPORTING','COUNTER_EVIDENCE','CONTEXT')),
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, claim_id, evidence_id, link_role),
  FOREIGN KEY (tenant_id, claim_id) REFERENCES contribution_claims(tenant_id, id),
  FOREIGN KEY (tenant_id, evidence_id) REFERENCES evidence_nodes(tenant_id, id)
);

CREATE TABLE attribution_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  claim_id uuid NOT NULL,
  decision_version integer NOT NULL,
  status text NOT NULL CHECK (status IN ('APPROVED','PARTIALLY_APPROVED','REJECTED','SUPERSEDED')),
  adjudicator_person_id uuid NOT NULL,
  accepted_facts jsonb NOT NULL DEFAULT '[]'::jsonb,
  rejected_facts jsonb NOT NULL DEFAULT '[]'::jsonb,
  contribution_dimensions jsonb NOT NULL DEFAULT '{}'::jsonb,
  rationale text NOT NULL,
  confidence_band text,
  effective_at timestamptz NOT NULL DEFAULT now(),
  supersedes_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, claim_id, decision_version),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, claim_id) REFERENCES contribution_claims(tenant_id, id),
  FOREIGN KEY (tenant_id, adjudicator_person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, supersedes_id) REFERENCES attribution_decisions(tenant_id, id)
);

CREATE TABLE policy_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  policy_code text NOT NULL,
  version integer NOT NULL,
  status text NOT NULL CHECK (status IN ('DRAFT','VALIDATED','PENDING_APPROVAL','APPROVED','PUBLISHED','RETIRED')),
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  rule_ast jsonb NOT NULL,
  rule_schema_version text NOT NULL,
  approved_by uuid,
  approved_at timestamptz,
  content_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, policy_code, version),
  UNIQUE (tenant_id, id),
  CHECK (effective_to IS NULL OR effective_to > effective_from)
);

CREATE TABLE rubrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  code text NOT NULL,
  name text NOT NULL,
  dimensions jsonb NOT NULL,
  scoring_anchors jsonb NOT NULL,
  status text NOT NULL CHECK (status IN ('DRAFT','APPROVED','PUBLISHED','RETIRED')),
  version integer NOT NULL,
  effective_from date NOT NULL,
  effective_to date,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, code, version),
  UNIQUE (tenant_id, id),
  CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

ALTER TABLE evaluation_cycles
  ADD CONSTRAINT fk_cycle_policy FOREIGN KEY (tenant_id, policy_version_id) REFERENCES policy_versions(tenant_id, id);
ALTER TABLE evaluation_cycles
  ADD CONSTRAINT fk_cycle_rubric FOREIGN KEY (tenant_id, rubric_version_id) REFERENCES rubrics(tenant_id, id);

CREATE TABLE evaluation_drafts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  cycle_id uuid NOT NULL,
  person_id uuid NOT NULL,
  generated_by_type text NOT NULL CHECK (generated_by_type IN ('AGENT','USER','SYSTEM')),
  generated_by_id uuid,
  evidence_snapshot_hash text NOT NULL,
  draft_payload jsonb NOT NULL,
  strengths jsonb NOT NULL DEFAULT '[]'::jsonb,
  counter_evidence jsonb NOT NULL DEFAULT '[]'::jsonb,
  missing_information jsonb NOT NULL DEFAULT '[]'::jsonb,
  uncertainty jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'DRAFT',
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE evaluation_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  cycle_id uuid NOT NULL,
  person_id uuid NOT NULL,
  decision_version integer NOT NULL,
  status text NOT NULL CHECK (status IN ('APPROVED','SUPERSEDED','WITHDRAWN')),
  rubric_version_id uuid NOT NULL,
  evidence_snapshot_hash text NOT NULL,
  scores jsonb NOT NULL,
  rationale text NOT NULL,
  reviewer_person_id uuid NOT NULL,
  approved_at timestamptz,
  supersedes_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, cycle_id, person_id, decision_version),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, rubric_version_id) REFERENCES rubrics(tenant_id, id),
  FOREIGN KEY (tenant_id, reviewer_person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, supersedes_id) REFERENCES evaluation_decisions(tenant_id, id)
);

CREATE TABLE calculation_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  cycle_id uuid NOT NULL,
  policy_version_id uuid NOT NULL,
  engine_version text NOT NULL,
  input_snapshot_hash text NOT NULL,
  status calculation_status NOT NULL DEFAULT 'CREATED',
  started_at timestamptz,
  finished_at timestamptz,
  trace_ref text,
  result_hash text,
  failure_code text,
  requested_by uuid NOT NULL,
  version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, policy_version_id) REFERENCES policy_versions(tenant_id, id),
  FOREIGN KEY (tenant_id, requested_by) REFERENCES users(id),
  CHECK (finished_at IS NULL OR started_at IS NULL OR finished_at >= started_at)
);
CREATE INDEX idx_calc_cycle_created ON calculation_runs(tenant_id, cycle_id, created_at DESC);

CREATE TABLE calculation_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  calculation_run_id uuid NOT NULL,
  person_id uuid NOT NULL,
  incentive_type text NOT NULL,
  base_amount numeric(20,6) NOT NULL,
  multiplier numeric(20,8) NOT NULL DEFAULT 1,
  raw_amount numeric(20,6) NOT NULL,
  rounded_amount numeric(20,6) NOT NULL,
  currency char(3) NOT NULL,
  trace jsonb NOT NULL,
  result_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, calculation_run_id) REFERENCES calculation_runs(tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE amount_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  person_id uuid NOT NULL,
  cycle_id uuid NOT NULL,
  calculation_run_id uuid NOT NULL,
  calculation_line_id uuid,
  entry_type text NOT NULL CHECK (entry_type IN ('INCENTIVE','ADJUSTMENT','REVERSAL','RECOVERY')),
  amount numeric(20,6) NOT NULL,
  currency char(3) NOT NULL,
  status ledger_status NOT NULL DEFAULT 'PROVISIONAL',
  source_entry_id uuid,
  locked_at timestamptz,
  idempotency_key text NOT NULL,
  entry_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, calculation_run_id) REFERENCES calculation_runs(tenant_id, id),
  FOREIGN KEY (tenant_id, calculation_line_id) REFERENCES calculation_lines(tenant_id, id),
  FOREIGN KEY (tenant_id, source_entry_id) REFERENCES amount_ledger(tenant_id, id),
  CHECK ((status <> 'LOCKED') OR locked_at IS NOT NULL)
);
CREATE INDEX idx_ledger_person_created ON amount_ledger(tenant_id, person_id, created_at DESC);
CREATE INDEX idx_ledger_cycle_status ON amount_ledger(tenant_id, cycle_id, status);

CREATE TABLE adjustment_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  original_ledger_id uuid NOT NULL,
  adjustment_ledger_id uuid NOT NULL,
  reason_code text NOT NULL,
  explanation text NOT NULL,
  approved_by uuid NOT NULL,
  approved_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, adjustment_ledger_id),
  FOREIGN KEY (tenant_id, original_ledger_id) REFERENCES amount_ledger(tenant_id, id),
  FOREIGN KEY (tenant_id, adjustment_ledger_id) REFERENCES amount_ledger(tenant_id, id),
  FOREIGN KEY (tenant_id, approved_by) REFERENCES users(id)
);

CREATE TABLE settlement_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  cycle_id uuid NOT NULL,
  batch_no text NOT NULL,
  status settlement_status NOT NULL DEFAULT 'DRAFT',
  currency char(3),
  total_amount numeric(20,6) NOT NULL DEFAULT 0,
  line_count integer NOT NULL DEFAULT 0,
  approved_by uuid,
  approved_at timestamptz,
  settled_at timestamptz,
  external_reference text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, batch_no),
  UNIQUE (tenant_id, id),
  FOREIGN KEY (tenant_id, cycle_id) REFERENCES evaluation_cycles(tenant_id, id),
  FOREIGN KEY (tenant_id, approved_by) REFERENCES users(id)
);

CREATE TABLE settlement_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  batch_id uuid NOT NULL,
  ledger_id uuid NOT NULL,
  person_id uuid NOT NULL,
  amount numeric(20,6) NOT NULL,
  currency char(3) NOT NULL,
  status text NOT NULL DEFAULT 'PENDING',
  external_reference text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, batch_id, ledger_id),
  FOREIGN KEY (tenant_id, batch_id) REFERENCES settlement_batches(tenant_id, id),
  FOREIGN KEY (tenant_id, ledger_id) REFERENCES amount_ledger(tenant_id, id),
  FOREIGN KEY (tenant_id, person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE appeal_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  appellant_person_id uuid NOT NULL,
  target_type text NOT NULL CHECK (target_type IN ('ATTRIBUTION','EVALUATION','LEDGER')),
  target_id uuid NOT NULL,
  appeal_reason_code text NOT NULL,
  statement text NOT NULL,
  evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','ASSIGNED','UNDER_REVIEW','UPHELD','CHANGED','REJECTED','CLOSED')),
  reviewer_person_id uuid,
  resolution text,
  resolved_at timestamptz,
  supersedes_decision_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, appellant_person_id) REFERENCES people(tenant_id, id),
  FOREIGN KEY (tenant_id, reviewer_person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE agent_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  agent_type text NOT NULL,
  trigger_type text NOT NULL,
  trigger_ref text,
  status agent_task_status NOT NULL DEFAULT 'QUEUED',
  risk_tier text NOT NULL CHECK (risk_tier IN ('T0','T1','T2','T3')),
  requested_by_type text NOT NULL CHECK (requested_by_type IN ('USER','AGENT','SYSTEM')),
  requested_by_id uuid,
  input_ref jsonb NOT NULL,
  output_ref jsonb,
  attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz,
  idempotency_key text NOT NULL,
  correlation_id uuid NOT NULL,
  last_error_code text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key),
  UNIQUE (tenant_id, id)
);
CREATE INDEX idx_agent_tasks_ready ON agent_tasks(tenant_id, status, next_attempt_at);

CREATE TABLE workflow_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  agent_task_id uuid NOT NULL,
  workflow_name text NOT NULL,
  workflow_version text NOT NULL,
  status text NOT NULL,
  current_step text,
  state jsonb NOT NULL DEFAULT '{}'::jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  finished_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, agent_task_id) REFERENCES agent_tasks(tenant_id, id)
);

CREATE TABLE ai_suggestion_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  agent_task_id uuid NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  suggestion_type text NOT NULL,
  model_provider text,
  model_name text,
  prompt_version text NOT NULL,
  input_hash text NOT NULL,
  output_json jsonb NOT NULL,
  validation_status text NOT NULL,
  accepted_by uuid,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (tenant_id, agent_task_id) REFERENCES agent_tasks(tenant_id, id),
  FOREIGN KEY (tenant_id, accepted_by) REFERENCES users(id)
);

CREATE TABLE approval_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  action_type text NOT NULL,
  target_type text NOT NULL,
  target_id uuid NOT NULL,
  requested_by_type text NOT NULL,
  requested_by_id uuid,
  risk_tier text NOT NULL CHECK (risk_tier IN ('T0','T1','T2','T3')),
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','EXPIRED','CANCELLED')),
  expires_at timestamptz,
  payload_hash text NOT NULL,
  idempotency_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key),
  UNIQUE (tenant_id, id)
);

CREATE TABLE approval_decisions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  request_id uuid NOT NULL,
  decision text NOT NULL CHECK (decision IN ('APPROVE','REJECT')),
  approver_person_id uuid NOT NULL,
  reason text,
  decided_at timestamptz NOT NULL DEFAULT now(),
  auth_context jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, request_id, approver_person_id),
  FOREIGN KEY (tenant_id, request_id) REFERENCES approval_requests(tenant_id, id),
  FOREIGN KEY (tenant_id, approver_person_id) REFERENCES people(tenant_id, id)
);

CREATE TABLE audit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  actor_type text NOT NULL CHECK (actor_type IN ('USER','AGENT','SYSTEM','INTEGRATION')),
  actor_id uuid,
  action text NOT NULL,
  object_type text NOT NULL,
  object_id uuid,
  before_hash text,
  after_hash text,
  reason text,
  correlation_id uuid NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  source_ip inet,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_object_time ON audit_events(tenant_id, object_type, object_id, occurred_at DESC);

CREATE TABLE outbox_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  event_type text NOT NULL,
  schema_version text NOT NULL,
  payload jsonb NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz,
  attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_outbox_unpublished ON outbox_events(next_attempt_at, occurred_at) WHERE published_at IS NULL;

CREATE TABLE inbox_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenants(id),
  consumer_name text NOT NULL,
  message_id text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  status text NOT NULL DEFAULT 'RECEIVED' CHECK (status IN ('RECEIVED','PROCESSED','FAILED','IGNORED')),
  error_code text,
  UNIQUE (tenant_id, consumer_name, message_id)
);

-- RLS is intentionally not enabled here by default until the application role,
-- tenant-context transaction setup, and complete table policy set are reviewed.
-- Enabling partial RLS without complete policies can create a false sense of security.

COMMIT;
