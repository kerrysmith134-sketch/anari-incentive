# Pre-code review checklist

## Must pass before production implementation
- [ ] Validate SQL by running migration against the chosen PostgreSQL version.
- [ ] Add automated migration test and migration rollback/forward-fix strategy.
- [ ] Run OpenAPI lint and resolve path parameter/reference issues.
- [ ] Review same-tenant FK coverage for every tenant-owned relationship.
- [ ] Complete RLS policies for every tenant-owned table before enabling RLS in production.
- [ ] Add DB trigger/privilege controls preventing UPDATE/DELETE of locked ledger and audit rows.
- [ ] Define exact policy DSL grammar, decimal semantics, null behavior and rounding.
- [ ] Add outbox publisher and inbox consumer tests under duplicate delivery.
- [ ] Build 5–10 anonymized order fixtures with expected work-package and evidence graph.
- [ ] Obtain Finance/HR/Legal review for policy, appeal, retention and settlement details.
- [ ] Run security tests for tenant boundary, privilege escalation, prompt injection and secrets.
- [ ] Run shadow calculation against a manually reconciled cycle before money is paid.
