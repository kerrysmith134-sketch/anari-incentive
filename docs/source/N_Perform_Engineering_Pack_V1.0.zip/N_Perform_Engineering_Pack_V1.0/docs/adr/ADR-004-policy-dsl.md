# ADR-004: Restricted Policy DSL

- Status: Proposed
- Decision: Incentive rules are represented as a versioned, schema-validated AST; never execute arbitrary JavaScript/Python from tenant policy.
- Required: static type checking, explicit null/missing-data behavior, decimal arithmetic, deterministic rounding, boundary tests, effective-date validation, approval separation, immutable published versions.
- Open questions: supported operators, expression complexity limits, reference evaluator implementation.
