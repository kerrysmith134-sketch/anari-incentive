# ADR-003: Immutable Incentive Ledger

- Status: Proposed
- Decision: A locked ledger entry is immutable. Corrections are represented by new adjustment/reversal entries linked to the original.
- Locking requires: approved policy version, fixed input snapshot, calculation trace, independent reference calculation match, valid approvals, idempotency checks, and total reconciliation.
- Monetary arithmetic uses decimal/numeric with explicit rounding policy.
- Open questions: payroll/finance export semantics, currency conversion and FX date, retention period.
