# ADR-002: Idempotency and Outbox/Inbox

- Status: Proposed
- Decision: Important write APIs require Idempotency-Key; external source events are deduplicated by source identity/version; domain events are written to Outbox in the same transaction as business state.
- Consumers use Inbox uniqueness `(tenant_id, consumer_name, message_id)` and must tolerate at-least-once delivery.
- Do not perform external HTTP calls inside a database transaction.
- Retry transient failures with exponential backoff and jitter; dead-letter after a bounded number of attempts.
- Open questions: key retention period, retry ceilings, message broker choice.
