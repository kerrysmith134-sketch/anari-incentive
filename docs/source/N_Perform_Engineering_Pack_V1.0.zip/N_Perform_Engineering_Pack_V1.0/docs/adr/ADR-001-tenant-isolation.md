# ADR-001: Tenant Isolation

- Status: Proposed
- Decision: Every tenant-owned row has `tenant_id`; service-layer authorization is mandatory; PostgreSQL RLS is an additional defense-in-depth layer.
- Rules:
  1. Tenant context is derived from validated identity and membership.
  2. Never trust client-supplied tenant ID for authorization.
  3. Tenant-owned foreign keys must enforce same-tenant references, preferably with composite unique/FK constraints.
  4. Cross-tenant support access requires explicit break-glass permission, expiry, reason, and audit event.
- Consequences: RLS policy coverage and connection-pool context lifecycle are release gates.
- Open questions: application DB role; policy coverage across all tenant tables; admin support workflow.
